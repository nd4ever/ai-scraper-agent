import argparse
import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from src.scraper import (
    fetch_azure_community_blog_headlines,
    fetch_azure_updates,
    fetch_azure_youtube_videos,
    fetch_techcommunity,
)
from src.scraper import get_current_month_to_date_range, get_previous_week_range


def _safe_fetch(label, fetch_fn, start_date, end_date):
    """Run a source fetch, returning [] (instead of aborting) on failure."""
    try:
        return fetch_fn(start_date, end_date)
    except Exception as exc:  # noqa: BLE001
        print(f"WARNING: {label} fetch failed ({exc}). Using empty list for this source.")
        return []


def refresh_output(output_path: str) -> dict:
    week_start_date, week_end_date = get_previous_week_range()
    month_start_date, month_end_date = get_current_month_to_date_range()

    tech = _safe_fetch("techcommunity (week)", fetch_techcommunity, week_start_date, week_end_date)
    updates = _safe_fetch("azure_updates (week)", fetch_azure_updates, week_start_date, week_end_date)
    azure_blog_headlines = _safe_fetch("azure_community_blog_headlines (week)", fetch_azure_community_blog_headlines, week_start_date, week_end_date)
    azure_youtube_videos = _safe_fetch("azure_youtube_videos (week)", fetch_azure_youtube_videos, week_start_date, week_end_date)

    tech_month = _safe_fetch("techcommunity (month)", fetch_techcommunity, month_start_date, month_end_date)
    updates_month = _safe_fetch("azure_updates (month)", fetch_azure_updates, month_start_date, month_end_date)
    azure_blog_headlines_month = _safe_fetch("azure_community_blog_headlines (month)", fetch_azure_community_blog_headlines, month_start_date, month_end_date)
    azure_youtube_videos_month = _safe_fetch("azure_youtube_videos (month)", fetch_azure_youtube_videos, month_start_date, month_end_date)

    payload = {
        "week_start": week_start_date.isoformat(),
        "week_end": week_end_date.isoformat(),
        "techcommunity": tech,
        "azure_updates": updates,
        "azure_community_blog_headlines": azure_blog_headlines,
        "azure_youtube_videos": azure_youtube_videos,
        "month_start": month_start_date.isoformat(),
        "month_end": month_end_date.isoformat(),
        "techcommunity_month": tech_month,
        "azure_updates_month": updates_month,
        "azure_community_blog_headlines_month": azure_blog_headlines_month,
        "azure_youtube_videos_month": azure_youtube_videos_month,
    }

    Path(output_path).write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return payload


class UnifiedHandler(SimpleHTTPRequestHandler):
    """Unified handler that serves tabbed interface or static files."""
    
    def do_GET(self):
        # Route root path to the tabbed interface
        if self.path in {'/', ''}:
            self.path = '/index.html'
        return super().do_GET()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Refresh output.json and serve unified tabbed web dashboard."
    )
    parser.add_argument("--out", type=str, default="output.json", help="Output JSON path")
    parser.add_argument("--port", type=int, default=8000, help="HTTP server port")
    parser.add_argument("--bind", type=str, default="127.0.0.1", help="Address to bind")
    args = parser.parse_args()

    start_date, end_date = get_previous_week_range()
    month_start, month_end = get_current_month_to_date_range()
    print(
        f"Refreshing weekly data for {start_date} to {end_date} "
        f"and monthly data for {month_start} to {month_end}..."
    )
    try:
        payload = refresh_output(args.out)
        print(
            "Wrote "
            f"{len(payload['techcommunity'])} techcommunity items, "
            f"{len(payload['azure_updates'])} azure updates, "
            f"{len(payload['azure_community_blog_headlines'])} azure community blog headlines, "
            f"{len(payload['azure_youtube_videos'])} Azure YouTube videos "
            f"for previous week, plus "
            f"{len(payload['techcommunity_month'])} techcommunity items, "
            f"{len(payload['azure_updates_month'])} azure updates, "
            f"{len(payload['azure_community_blog_headlines_month'])} azure community blog headlines, "
            f"{len(payload['azure_youtube_videos_month'])} Azure YouTube videos "
            f"for current month to date "
            f"to {args.out}"
        )
    except Exception as exc:  # noqa: BLE001
        if Path(args.out).exists():
            print(
                f"WARNING: Failed to refresh data ({exc}). "
                f"Serving existing {args.out} instead."
            )
        else:
            print(
                f"ERROR: Failed to refresh data ({exc}) and no existing "
                f"{args.out} was found to serve."
            )
            raise

    server = ThreadingHTTPServer((args.bind, args.port), UnifiedHandler)
    print(f"Serving unified dashboard at http://{args.bind}:{args.port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
